import  React,{useState} from 'react';
import { Text, View, StyleSheet,ScrollView } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  const [people,setPeople]=useState([
  {name:'serhat',key:1},
  {name:'serpil',key:2},
  {name:'murat',key:3},
  {name:'selim',key:4},
   {name:'serhat',key:1},
  {name:'serpil',key:2},
  {name:'murat',key:3},
  {name:'selim',key:4},
   {name:'serhat',key:1},
  {name:'serpil',key:2},
  {name:'murat',key:3},
  {name:'selim',key:4},
]);

  return (
    <View style={styles.container}>
   <ScrollView>   
{people.map(item=>
( <View key={item.key}>
  <Text style={styles.item} >
  {item.name}
  </Text>
  </View>
))
 }</ScrollView>
    </View>
   
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
   alignItems:'center'
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color:"#f00"
  },
  footer:{color:'#00f',fontSize:40
  },buttonContainer:{
    innerWidth:20,
    marginTop:20,
    padding:10

  },
  input:{
borderWidth:1,
padding:2,
margin:8,
width:180,
borderColor:"#00f",
alignItems:'center',
  },
  item:{
    color:'black',
    backgroundColor:'pink',
    padding:3,
    margin:5,
    fontSize:50,
    paddingTop:10,
    paddingHorizontal:50,
  }
  
});
